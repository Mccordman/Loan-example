#pragma once
#include<iostream>
#include<string>
#include<math.h>                                                //I put the implementation file and the header file together using in-line definitions
using namespace std;
class homeMortgage      //defining the class
{
private:
	double loanAmount, rate, monthlyInterestRate, paymentAmount, term, paidsofar=0.0;   //setting private members
	int years, numbers_payments, monthspaid;
public:
	void setLoan()
	{
		loanAmount = -1;         //setting the loan amount to -1 at the start to make the while loop work
		while (loanAmount < 0)
		{
			cout << "Enter the dollar amount of the loan (non-negative): " << endl;   //function to set the loan amount
			cin >> loanAmount;
		}
		
	}
	void setRate()   //mutator function to set the annual rate on a loanand to determine the monthly interest rate
	{
		rate = -1;
		while (rate < 0)  //input validation
		{
			cout << "Enter the annual interest rate (non-negative): " << endl;  //function to set the annual interest rate
			cin >> rate;
			monthlyInterestRate = rate / 12;
		}

	}
	void setYears()   //setting the years on the loan with a function
	{
		years = -1;
		while (years < 0)
		{
			cout << "Enter the number of years on the loan: " << endl;    //function to set the number of years on the loan
			cin >> years;
			numbers_payments = years * 12;
		}
	}
	void Terms()
	{
		term = pow(1 + monthlyInterestRate, numbers_payments);   //determining term
		
	}
	//the payment function can be used to "make a payment" on the loan
	double payment()  //determining the monthly payment and how much has been paid so far based on how many payments have been made
	{
		paymentAmount = (loanAmount * monthlyInterestRate * term) / (term - 1);  //determining monthly payment amount
		paidsofar = paidsofar + paymentAmount;
		monthspaid++;
		return paymentAmount;  
	}

	void amountpaid() const  //function to determine the total amount of moeny paid to the bank at the end of however many months.
		                 //the total amount will be paid when paidsofar is greater or equal to the total loan amount.
	{
		cout << "The monthly payment amount is: $" << paymentAmount << endl;
		cout << "So far you have paid "<<monthspaid<<" months out of "<<numbers_payments<<" months totaling to $" << paidsofar <<" paid to the bank."<< endl;
		cout << "\n";
		cout << "The total amount paid to the bank at the end of the loan period is: $" << (paymentAmount) * (numbers_payments) << endl;

	}

	homeMortgage()  //default constructor initialization
	{
		loanAmount = 0;
		monthlyInterestRate = 0.0;
		numbers_payments = 0;
		paymentAmount = 0;
		rate = 0.0;
		term = 0.0;
		years = 0;
		paidsofar = 0.0;
		monthspaid = 0;
	}

	

};
#include"mortgage.h"   //including header file
#include<iostream>
#include<string>
#include<math.h>   //including math library for the power function
using namespace std;

int main()  //creating test function
{
	homeMortgage home1;  //creating object of the class

	home1.setLoan();  //using mutator functions to set the loan amount, the annual rate, and the years on the loan
	home1.setRate();
	home1.setYears();

	home1.Terms();     //calling terms function to determine what the term is for this specific object of the class
	home1.payment();    //calling payment function to determine monthly payment, and to "make a payment" on the loan
	home1.payment();   //calling it again to add a payment to the loan
	home1.amountpaid();  //calling this function to display results on to the console, showing the amount paid currently, and what will end up being paid at the end of the loan period

	return 0;  //returning 0
}